data = 'data/input3.fasta'
P = 'AAGAAC'

seq = ''

with open(data, 'r') as f:
    f.readline()  # skip the header
    for line in f:
        seq += line[:-1]

count = 0
bases = {'A': 0, 'C': 0, 'G': 0, 'T': 0}

for char in seq:
    bases[char] += 1

for i in range(len(seq) - len(P) + 1):
    if seq[i:i+len(P)] == P:
        print(i)
        count += 1

        i = 0



print('Number of patterns in file:', count)
print(bases)